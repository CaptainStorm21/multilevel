import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registration-step4',
  templateUrl: './registration-step4.component.html',
  styleUrls: ['./registration-step4.component.css']
})
export class RegistrationStep4Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
