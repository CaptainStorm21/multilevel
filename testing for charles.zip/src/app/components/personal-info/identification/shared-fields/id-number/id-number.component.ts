import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-id-number',
  templateUrl: './id-number.component.html',
  styleUrls: ['./id-number.component.scss']
})
export class IdNumberComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
