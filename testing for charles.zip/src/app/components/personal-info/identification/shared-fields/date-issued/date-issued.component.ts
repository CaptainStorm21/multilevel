import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-date-issued',
  templateUrl: './date-issued.component.html',
  styleUrls: ['./date-issued.component.scss']
})
export class DateIssuedComponent implements OnInit {


    constructor() { }

    ngOnInit() {
    }

}
