import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-date-expiration',
  templateUrl: './date-expiration.component.html',
  styleUrls: ['./date-expiration.component.scss']
})
export class DateExpirationComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}

