import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-driver-license',
  templateUrl: './driver-license.component.html',
  styleUrls: ['./driver-license.component.scss']
})
export class DriverLicenseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
