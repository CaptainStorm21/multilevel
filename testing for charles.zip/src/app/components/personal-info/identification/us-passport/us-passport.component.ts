import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-us-passport',
  templateUrl: './us-passport.component.html',
  styleUrls: ['./us-passport.component.scss']
})
export class UsPassportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
