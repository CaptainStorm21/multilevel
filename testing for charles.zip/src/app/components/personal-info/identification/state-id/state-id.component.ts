import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-state-id',
  templateUrl: './state-id.component.html',
  styleUrls: ['./state-id.component.scss']
})
export class StateIdComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
