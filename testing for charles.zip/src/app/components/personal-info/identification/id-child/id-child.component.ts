import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-id-child',
  templateUrl: './id-child.component.html',
  styleUrls: ['./id-child.component.css']
})
export class ChildIdComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
