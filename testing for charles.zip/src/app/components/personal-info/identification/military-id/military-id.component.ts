import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-military-id',
  templateUrl: './military-id.component.html',
  styleUrls: ['./military-id.component.scss']
})
export class MilitaryIdComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
