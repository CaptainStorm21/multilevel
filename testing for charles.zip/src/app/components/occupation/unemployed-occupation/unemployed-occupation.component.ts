import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unemployed-occupation',
  templateUrl: './unemployed-occupation.component.html',
  styleUrls: ['./unemployed-occupation.component.scss']
})
export class UnemployedOccupationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
