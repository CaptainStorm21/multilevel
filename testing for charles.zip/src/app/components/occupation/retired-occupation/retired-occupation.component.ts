import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-retired-occupation',
  templateUrl: './retired-occupation.component.html',
  styleUrls: ['./retired-occupation.component.scss']
})
export class RetiredOccupationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
