import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-occupation',
  templateUrl: './student-occupation.component.html',
  styleUrls: ['./student-occupation.component.scss']
})
export class StudentOccupationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
