import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employed-occupation',
  templateUrl: './employed-occupation.component.html',
  styleUrls: ['./employed-occupation.component.scss']
})
export class EmployedOccupationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
