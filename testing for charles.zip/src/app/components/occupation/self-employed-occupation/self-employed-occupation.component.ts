import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-self-employed-occupation',
  templateUrl: './self-employed-occupation.component.html',
  styleUrls: ['./self-employed-occupation.component.scss']
})
export class SelfEmployedOccupationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
