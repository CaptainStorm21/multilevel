import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registration-step5',
  templateUrl: './registration-step5.component.html',
  styleUrls: ['./registration-step5.component.css']
})
export class RegistrationStep5Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
